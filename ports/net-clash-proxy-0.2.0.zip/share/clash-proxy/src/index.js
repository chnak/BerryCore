'use strict';

// Patch js2ray transports (TCP+TLS, wss URL) before it is loaded.
require('./patch-js2ray');

const path = require('path');
const { loadConfig } = require('./config');
const { makeMatcher, createSelector } = require('./rules');
const { setVerbose, info } = require('./common');
const vmess = require('./vmess');
const mixed = require('./mixed');

const dir = path.resolve(__dirname, '..');
const args = process.argv.slice(2);
const cfgFile = process.env.CLASH_CONFIG || path.join(dir, 'config.yaml');

let nodeArg = null;
for (let i = 0; i < args.length; i++) {
  if (args[i] === '--node' && args[i + 1]) nodeArg = args[++i];
}

let cfg;
try {
  cfg = loadConfig(cfgFile, { node: nodeArg });
} catch (e) {
  console.error('clash-proxy: config error:', e.message);
  process.exit(1);
}

if (process.env.CLASH_MODE) cfg.mode = String(process.env.CLASH_MODE).toLowerCase();
setVerbose(process.env.CLASH_VERBOSE === '1' || cfg.logLevel === 'debug');

if (args.includes('--list')) {
  console.log('PROXIES (' + cfg.proxies.length + '):');
  for (const p of cfg.proxies) console.log('  [' + p.type + '] ' + p.name + '  ' + p.server + ':' + p.port);
  console.log('GROUPS:');
  for (const g of cfg.groups.values()) console.log('  [' + g.type + '] ' + g.name + ' -> ' + g.proxies.length + ' entries');
  console.log('default group: ' + cfg.defaultGroupName);
  process.exit(0);
}

if (args.includes('--check')) {
  console.log('config:', cfgFile);
  console.log('listen:', cfg.listenHost + ':' + cfg.port);
  console.log('proxies:', cfg.proxies.length, 'skipped:', cfg.skippedProxies);
  console.log('groups:', cfg.groups.size, 'rules:', cfg.rules.list.length);
  if (Object.keys(cfg.ruleStats).length) console.log('unsupported rules:', JSON.stringify(cfg.ruleStats));
  const ctx0 = { cfg, dir, matcher: makeMatcher(cfg), selector: createSelector(cfg), verbose: false };
  const sel = ctx0.selector.defaultTarget();
  console.log('selected node:', sel.kind === 'proxy' ? sel.proxy.name : sel.kind, 'via', sel.via);
  process.exit(0);
}

const ctx = {
  cfg,
  dir,
  matcher: makeMatcher(cfg),
  selector: createSelector(cfg),
  verbose: process.env.CLASH_VERBOSE === '1' || cfg.logLevel === 'debug',
};

info('clash-proxy starting');
info('config:', cfgFile);
info('proxies:', cfg.proxies.length, 'skipped:', cfg.skippedProxies, 'groups:', cfg.groups.size, 'rules:', cfg.rules.list.length);
if (Object.keys(cfg.ruleStats).length) info('unsupported rule types:', JSON.stringify(cfg.ruleStats));
const sel = ctx.selector.defaultTarget();
info('selected node:', sel.kind === 'proxy' ? sel.proxy.name : sel.kind, 'via', sel.via);

mixed.start(ctx);

// Record our own pid so the control script can stop the right process.
try {
  require('fs').writeFileSync(path.join(dir, 'clash-proxy.pid'), String(process.pid));
} catch (e) { /* not fatal */ }

function shutdown() {
  info('clash-proxy stopping');
  vmess.stopAll();
  process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
process.on('uncaughtException', (e) => {
  console.error('uncaughtException:', e && e.stack ? e.stack : e);
});
