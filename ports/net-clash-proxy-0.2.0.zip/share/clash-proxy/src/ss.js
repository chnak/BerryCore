'use strict';

const net = require('net');
const crypto = require('crypto');
const { Duplex } = require('stream');
const { evpBytesToKey, encodeTarget, targetHeaderLen, log } = require('./common');

const AEAD = {
  'aes-128-gcm': { keyLen: 16, node: 'aes-128-gcm' },
  'aes-192-gcm': { keyLen: 24, node: 'aes-192-gcm' },
  'aes-256-gcm': { keyLen: 32, node: 'aes-256-gcm' },
  'chacha20-ietf-poly1305': { keyLen: 32, node: 'chacha20-poly1305' },
  'chacha20-poly1305': { keyLen: 32, node: 'chacha20-poly1305' },
};

const STREAM = {
  'aes-128-cfb': { keyLen: 16, ivLen: 16, node: 'aes-128-cfb' },
  'aes-192-cfb': { keyLen: 24, ivLen: 16, node: 'aes-192-cfb' },
  'aes-256-cfb': { keyLen: 32, ivLen: 16, node: 'aes-256-cfb' },
  'aes-128-ctr': { keyLen: 16, ivLen: 16, node: 'aes-128-ctr' },
  'aes-192-ctr': { keyLen: 24, ivLen: 16, node: 'aes-192-ctr' },
  'aes-256-ctr': { keyLen: 32, ivLen: 16, node: 'aes-256-ctr' },
};

const MAX_CHUNK = 0x3fff;

function nonceBuf(n) {
  // Shadowsocks AEAD nonce: 12 bytes, 64-bit little-endian counter in the
  // first 8 bytes (high 4 bytes stay zero for practical counters).
  const b = Buffer.alloc(12);
  b.writeBigUInt64LE(BigInt(n), 0);
  return b;
}

class SSSocket extends Duplex {
  constructor(proxy, host, port) {
    super();
    this.proxy = proxy;
    this.targetHost = host;
    this.targetPort = port;
    this.raw = null;
    this.mode = null;
    this.ready = false;
    this.pending = [];
    this.decBuf = Buffer.alloc(0);
    this.saltOrIvDone = false;
    this.encSubkey = null;
    this.decSubkey = null;
    this.nodeCipher = null;
    this.encCounter = 0;
    this.decCounter = 0;
    this.pendingLen = null;
    this.encCipher = null;
    this.decCipher = null;
    this.headerDone = false;
    this.plainBuf = Buffer.alloc(0);
    this._connect();
  }

  _connect() {
    const raw = net.connect({ host: this.proxy.server, port: this.proxy.port });
    this.raw = raw;
    raw.setNoDelay(true);
    raw.on('connect', () => this._init());
    raw.on('data', (d) => this._onRawData(d));
    raw.on('error', (e) => {
      log('ss tcp error', this.proxy.name, e && e.message);
      // Some SS servers reset the TCP connection right after the final data.
      // Treat that as a normal EOF so buffered data can still be flushed.
      if (e && (e.code === 'ECONNRESET' || e.code === 'EPIPE')) this.push(null);
      else this.destroy(e);
    });
    raw.on('end', () => log('ss raw end', this.proxy.name));
    raw.on('close', () => { log('ss raw close', this.proxy.name); this.push(null); });
  }

  _init() {
    const cipher = String(this.proxy.cipher || '').toLowerCase();
    this.targetHeader = encodeTarget(this.targetHost, this.targetPort);
    if (AEAD[cipher]) {
      this.mode = 'aead';
      this.keyLen = AEAD[cipher].keyLen;
      this.nodeCipher = AEAD[cipher].node;
      this.masterKey = evpBytesToKey(this.proxy.password, this.keyLen);
      const salt = crypto.randomBytes(this.keyLen);
      this.encSubkey = Buffer.from(crypto.hkdfSync('sha1', this.masterKey, salt, Buffer.from('ss-subkey'), this.keyLen));
      this.salt = salt;
      log('ss salt', this.proxy.name, salt.toString('hex'));
      this.raw.write(salt);
      this._writeChunk(this.targetHeader);
      this.ready = true;
    } else if (STREAM[cipher]) {
      this.mode = 'stream';
      this.keyLen = STREAM[cipher].keyLen;
      this.nodeCipher = STREAM[cipher].node;
      this.masterKey = evpBytesToKey(this.proxy.password, this.keyLen);
      const iv = crypto.randomBytes(STREAM[cipher].ivLen);
      this.encCipher = crypto.createCipheriv(this.nodeCipher, this.masterKey, iv);
      this.raw.write(iv);
      this.raw.write(this.encCipher.update(this.targetHeader));
      this.ready = true;
    } else {
      this.destroy(new Error('unsupported shadowsocks cipher: ' + cipher));
      return;
    }
    const q = this.pending;
    this.pending = [];
    for (const chunk of q) this._encryptWrite(chunk);
    log('ss ready', this.proxy.name, this.mode, this.nodeCipher);
    this.emit('ready');
  }

  _seal(plain) {
    const n = this.encCounter++;
    const iv = nonceBuf(n);
    const c = crypto.createCipheriv(this.nodeCipher, this.encSubkey, iv);
    const ct = Buffer.concat([c.update(plain), c.final()]);
    const out = Buffer.concat([ct, c.getAuthTag()]);
    if (this._dbgSeal === undefined) this._dbgSeal = 0;
    if (this._dbgSeal < 16) log('ss seal', this.proxy.name, 'nonce', n, 'plain', plain.length, 'out', out.length, this._dbgSeal++);
    return out;
  }

  _open(box) {
    const tag = box.subarray(box.length - 16);
    const ct = box.subarray(0, box.length - 16);
    const d = crypto.createDecipheriv(this.nodeCipher, this.decSubkey, nonceBuf(this.decCounter++));
    d.setAuthTag(tag);
    return Buffer.concat([d.update(ct), d.final()]);
  }

  _writeChunk(buf) {
    for (let off = 0; off < buf.length; off += MAX_CHUNK) {
      const p = buf.subarray(off, Math.min(off + MAX_CHUNK, buf.length));
      const len = Buffer.alloc(2);
      len.writeUInt16BE(p.length, 0);
      const box = Buffer.concat([this._seal(len), this._seal(p)]);
      if (!this._dbgFirst) { this._dbgFirst = true; log('ss firstchunk', box.toString('hex')); }
      if (this._dbgWrites === undefined) this._dbgWrites = 0;
      if (this._dbgWrites < 12) log('ss tx chunk', this.proxy.name, this._dbgWrites++, p.length);
      this.raw.write(box);
    }
  }

  _encryptWrite(chunk) {
    if (this.mode === 'aead') {
      this._writeChunk(chunk);
    } else if (this.mode === 'stream') {
      this.raw.write(this.encCipher.update(chunk));
    }
  }

  _onRawData(d) {
    if (this.mode === 'aead') {
      this.decBuf = Buffer.concat([this.decBuf, d]);
      if (!this.saltOrIvDone) {
        if (this.decBuf.length < this.keyLen) return;
        const salt = this.decBuf.subarray(0, this.keyLen);
        this.decBuf = this.decBuf.subarray(this.keyLen);
        this.decSubkey = Buffer.from(crypto.hkdfSync('sha1', this.masterKey, salt, Buffer.from('ss-subkey'), this.keyLen));
        this.saltOrIvDone = true;
      }
      let idx = 0;
      while (true) {
        let len = this.pendingLen;
        if (len == null) {
          if (this.decBuf.length < 18) break;
          try { len = this._open(this.decBuf.subarray(0, 18)).readUInt16BE(0); }
          catch (e) {
            log('ss rx len fail', this.proxy.name, 'chunk', idx, 'nonce', this.decCounter - 1, e.message);
            this.destroy(e); return;
          }
          this.decBuf = this.decBuf.subarray(18);
          if (len > MAX_CHUNK) { this.destroy(new Error('ss chunk too large')); return; }
          this.pendingLen = len;
        }
        if (this.decBuf.length < len + 16) break;
        const box = this.decBuf.subarray(0, len + 16);
        this.decBuf = this.decBuf.subarray(len + 16);
        this.pendingLen = null;
        let pay;
        try { pay = this._open(box); }
        catch (e) {
          log('ss rx payload fail', this.proxy.name, 'chunk', idx, 'len', len, 'nonce', this.decCounter - 1, e.message);
          this.destroy(e); return;
        }
        if (this._dbgRx === undefined) this._dbgRx = 0;
        if (this._dbgRx < 10) {
          this._dbgRx++;
          log('ss rx data', this.proxy.name, len, 'head', pay.subarray(0, 12).toString('hex'));
        }
        this.push(pay);
        log('ss rx chunk', this.proxy.name, idx, len);
        idx++;
      }
    } else if (this.mode === 'stream') {
      this.plainBuf = Buffer.concat([this.plainBuf, d]);
      if (!this.saltOrIvDone) {
        const ivLen = STREAM[String(this.proxy.cipher).toLowerCase()].ivLen;
        if (this.plainBuf.length < ivLen) return;
        const iv = this.plainBuf.subarray(0, ivLen);
        this.plainBuf = this.plainBuf.subarray(ivLen);
        this.decCipher = crypto.createDecipheriv(this.nodeCipher, this.masterKey, iv);
        this.saltOrIvDone = true;
      }
      const out = this.decCipher.update(this.plainBuf);
      this.plainBuf = Buffer.alloc(0);
      if (!this.headerDone) {
        const need = targetHeaderLen(out, 0);
        if (!need) { this.plainBuf = out; return; }
        this.headerDone = true;
        if (out.length > need) this.push(out.subarray(need));
      } else if (out.length) {
        this.push(out);
      }
    }
  }

  _write(chunk, enc, cb) {
    if (!this.ready) { this.pending.push(chunk); return cb(); }
    this._encryptWrite(chunk);
    cb();
  }

  _read() {}

  _final(cb) {
    if (this.raw) this.raw.end();
    cb();
  }

  _destroy(err, cb) {
    if (this.raw) { this.raw.destroy(); this.raw = null; }
    cb(err);
  }
}

function connect(proxy, host, port) {
  return new SSSocket(proxy, host, port);
}

module.exports = { connect, AEAD, STREAM };
