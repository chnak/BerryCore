'use strict';

const net = require('net');

let VERBOSE = false;
function setVerbose(v) { VERBOSE = !!v; }
function log(...a) { if (VERBOSE) console.error(new Date().toISOString(), ...a); }
function info(...a) { console.log(new Date().toISOString(), ...a); }

// OpenSSL EVP_BytesToKey with MD5 (Shadowsocks legacy / AEAD master key)
function evpBytesToKey(password, keyLen) {
  const pw = Buffer.from(String(password), 'utf8');
  let out = Buffer.alloc(0);
  let prev = Buffer.alloc(0);
  while (out.length < keyLen) {
    prev = require('crypto').createHash('md5').update(Buffer.concat([prev, pw])).digest();
    out = Buffer.concat([out, prev]);
  }
  return out.subarray(0, keyLen);
}

function portBuf(p) {
  const b = Buffer.alloc(2);
  b.writeUInt16BE(p & 0xffff, 0);
  return b;
}

function ipv4ToBytes(ip) {
  return Buffer.from(ip.split('.').map(x => Number(x) & 0xff));
}

// Minimal IPv6 literal parser -> 16 bytes
function ipv6ToBytes(text) {
  let ip = String(text).split('%')[0];
  let head, tail;
  if (ip.includes('::')) {
    const parts = ip.split('::');
    head = parts[0] ? parts[0].split(':') : [];
    tail = parts[1] ? parts[1].split(':') : [];
  } else {
    head = ip.split(':');
    tail = [];
  }
  const expand = (parts) => {
    const out = [];
    for (const s of parts) {
      if (s.includes('.')) {
        const v = s.split('.').map(Number);
        out.push((((v[0] & 0xff) << 8) | (v[1] & 0xff)).toString(16));
        out.push((((v[2] & 0xff) << 8) | (v[3] & 0xff)).toString(16));
      } else {
        out.push(s || '0');
      }
    }
    return out;
  };
  head = expand(head);
  tail = expand(tail);
  const missing = 8 - (head.length + tail.length);
  const groups = head.concat(Array(Math.max(0, missing)).fill('0'), tail);
  const b = Buffer.alloc(16);
  for (let i = 0; i < 8; i++) b.writeUInt16BE(parseInt(groups[i] || '0', 16) & 0xffff, i * 2);
  return b;
}

// Shadowsocks target address (SOCKS5 address format)
function encodeTarget(host, port) {
  const fam = net.isIP(host);
  if (fam === 4) return Buffer.concat([Buffer.from([1]), ipv4ToBytes(host), portBuf(port)]);
  if (fam === 6) return Buffer.concat([Buffer.from([4]), ipv6ToBytes(host), portBuf(port)]);
  const d = Buffer.from(host, 'utf8');
  if (d.length > 255) throw new Error('target domain too long');
  return Buffer.concat([Buffer.from([3, d.length]), d, portBuf(port)]);
}

// Length of a SOCKS5 address at the start of buf, or 0 if incomplete
function targetHeaderLen(buf, off = 0) {
  if (buf.length < off + 1) return 0;
  const atyp = buf[off];
  if (atyp === 1) return buf.length >= off + 7 ? 7 : 0;
  if (atyp === 3) {
    if (buf.length < off + 2) return 0;
    const l = buf[off + 1];
    return buf.length >= off + 2 + l + 2 ? 4 + l : 0;
  }
  if (atyp === 4) return buf.length >= off + 19 ? 19 : 0;
  throw new Error('bad address type ' + atyp);
}

function ipv4ToInt(ip) {
  return ip.split('.').reduce((a, x) => ((a << 8) | (Number(x) & 0xff)) >>> 0, 0) >>> 0;
}
function inCidr4(ip, cidr) {
  const [base, bitsRaw] = String(cidr).split('/');
  const bits = Number(bitsRaw);
  if (!Number.isInteger(bits) || bits < 0 || bits > 32 || net.isIP(base) !== 4 || net.isIP(ip) !== 4) return false;
  const mask = bits === 0 ? 0 : (0xffffffff << (32 - bits)) >>> 0;
  return ((ipv4ToInt(ip) & mask) >>> 0) === ((ipv4ToInt(base) & mask) >>> 0);
}

function sanitizeName(name) {
  return String(name).replace(/[^A-Za-z0-9._-]+/g, '_').slice(0, 48) || 'node';
}

module.exports = {
  setVerbose, log, info,
  evpBytesToKey, portBuf, ipv4ToBytes, ipv6ToBytes, encodeTarget, targetHeaderLen,
  ipv4ToInt, inCidr4, sanitizeName,
};
