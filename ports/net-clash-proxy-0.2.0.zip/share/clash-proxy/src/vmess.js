'use strict';

const net = require('net');
const path = require('path');
const { log, sanitizeName, encodeTarget } = require('./common');

const bridges = new Map();
let nextPort = 32100;
let js2rayMod = null;

// Load js2ray lazily: it is only needed for VMess nodes and adds noticeable
// startup time on the device.
function getJs2ray() {
  if (!js2rayMod) js2rayMod = require('js2ray');
  return js2rayMod;
}

function buildNetwork(p) {
  if (p.network === 'ws' || p.network === 'http') {
    const opt = { path: p.wsPath || '/', headers: p.wsHeaders || {} };
    if (p.tls) {
      opt.tls = {
        serverName: p.servername || p.server,
        rejectUnauthorized: !p.skipCertVerify,
      };
    }
    return { type: p.network, address: p.server, port: p.port, option: opt };
  }
  const n = { type: 'tcp', address: p.server, port: p.port };
  if (p.tls) {
    n.option = {
      tls: {
        serverName: p.servername || p.server,
        rejectUnauthorized: !p.skipCertVerify,
      },
    };
  }
  return n;
}

function vmessSecurity(p) {
  const c = String(p.cipher || 'auto').toLowerCase();
  // js2ray's "auto" response handling is broken; pin a well-supported cipher.
  if (!c || c === 'auto') return 'aes-128-gcm';
  return c;
}

function findFreePort(cb, tries) {
  if (tries <= 0) return cb(new Error('no free local port'));
  const port = nextPort++;
  if (nextPort > 36000) nextPort = 32100;
  const probe = net.createServer();
  probe.once('error', () => { try { probe.close(); } catch (e) {} findFreePort(cb, tries - 1); });
  probe.listen(port, '127.0.0.1', () => {
    probe.close(() => cb(null, port));
  });
}

function ensureBridge(p, ctx, cb) {
  if (bridges.has(p.name)) return cb(null, bridges.get(p.name).port);

  const attempt = (tries) => {
    if (tries <= 0) return cb(new Error('could not allocate local port for vmess bridge'));
    findFreePort((err, port) => {
      if (err) return attempt(tries - 1);
      const storage = path.join(ctx.dir, '.vmess-' + sanitizeName(p.name) + '.json');
      const cfg = {
        inbounds: [{ protocol: 'socks', networks: [{ address: '127.0.0.1', port }] }],
        outbounds: [{
          tag: 'vmess',
          protocol: 'vmess',
          networks: [buildNetwork(p)],
          users: [{ id: p.uuid, security: vmessSecurity(p), alterId: p.alterId || 0 }],
        }],
        storage,
        debug: (...a) => { if (ctx.verbose) log('js2ray', ...a); },
      };
      try {
        const inst = getJs2ray().config(cfg);
        inst.start();
        bridges.set(p.name, { port, inst, storage });
        log('vmess bridge', p.name, '-> 127.0.0.1:' + port, 'security=' + vmessSecurity(p));
        cb(null, port);
      } catch (e) {
        log('vmess bridge failed', p.name, e && e.message);
        attempt(tries - 1);
      }
    }, tries);
  };
  attempt(5);
}

function connectViaSocks(localPort, host, port, cb) {
  const s = net.connect({ host: '127.0.0.1', port: localPort });
  let buf = Buffer.alloc(0);
  let stage = 0;
  let done = false;

  const finish = (err) => {
    if (done) return;
    done = true;
    s.removeListener('data', onData);
    s.removeListener('error', onError);
    if (err) { try { s.destroy(); } catch (e) {} return cb(err); }
    cb(null, s);
  };
  const onError = (e) => finish(e);
  const onData = (d) => {
    buf = Buffer.concat([buf, d]);
    for (;;) {
      if (stage === 0) {
        if (buf.length < 2) return;
        if (buf[0] !== 5 || buf[1] !== 0) return finish(new Error('bridge socks handshake failed'));
        buf = buf.subarray(2);
        let req;
        try { req = Buffer.concat([Buffer.from([5, 1, 0]), encodeTarget(host, port)]); }
        catch (e) { return finish(e); }
        s.write(req);
        stage = 1;
        continue;
      }
      if (stage === 1) {
        if (buf.length < 4) return;
        const code = buf[1];
        const atyp = buf[3];
        let need;
        if (atyp === 1) need = 10;
        else if (atyp === 4) need = 22;
        else if (atyp === 3) { if (buf.length < 5) return; need = 7 + buf[4]; }
        else return finish(new Error('bridge socks bad atyp ' + atyp));
        if (buf.length < need) return;
        const rest = buf.subarray(need);
        if (code !== 0) return finish(new Error('bridge socks connect code ' + code));
        if (rest.length) s.unshift(rest);
        return finish(null);
      }
    }
  };
  s.on('data', onData);
  s.on('error', onError);
  s.once('connect', () => s.write(Buffer.from([5, 1, 0])));
  s.setNoDelay(true);
}

function connect(p, host, port, ctx, cb) {
  ensureBridge(p, ctx, (err, localPort) => {
    if (err) return cb(err);
    connectViaSocks(localPort, host, port, cb);
  });
}

function stopAll() {
  for (const b of bridges.values()) {
    try { b.inst.stop(); } catch (e) {}
  }
  bridges.clear();
}

module.exports = { connect, stopAll };
