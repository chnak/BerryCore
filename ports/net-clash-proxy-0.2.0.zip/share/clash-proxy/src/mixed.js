'use strict';

const net = require('net');
const { info, log } = require('./common');
const ss = require('./ss');
const vmess = require('./vmess');

class Reader {
  constructor(socket, initial) {
    this.socket = socket;
    this.buf = initial ? Buffer.from(initial) : Buffer.alloc(0);
    this.waiters = [];
    this.ended = false;
    this.error = null;
    this.onData = (d) => { this.buf = Buffer.concat([this.buf, d]); this.pump(); };
    this.onEnd = () => { this.ended = true; this.pump(); };
    this.onErr = (e) => { this.error = e; this.ended = true; this.pump(); };
    socket.on('data', this.onData);
    socket.on('end', this.onEnd);
    socket.on('error', this.onErr);
  }

  pump() {
    while (this.waiters.length) {
      const w = this.waiters[0];
      if (this.buf.length >= w.n) {
        const d = this.buf.subarray(0, w.n);
        this.buf = this.buf.subarray(w.n);
        this.waiters.shift();
        w.resolve(d);
      } else if (this.ended) {
        this.waiters.shift();
        w.reject(this.error || new Error('unexpected EOF'));
      } else {
        break;
      }
    }
  }

  read(n) {
    if (this.buf.length >= n) {
      const d = this.buf.subarray(0, n);
      this.buf = this.buf.subarray(n);
      return Promise.resolve(d);
    }
    return new Promise((resolve, reject) => this.waiters.push({ n, resolve, reject }));
  }

  readUntil(marker, max) {
    max = max || 65536;
    const mark = Buffer.isBuffer(marker) ? marker : Buffer.from(marker);
    return new Promise((resolve, reject) => {
      const tryOnce = () => {
        const idx = this.buf.indexOf(mark);
        if (idx >= 0) {
          const end = idx + mark.length;
          const d = this.buf.subarray(0, end);
          this.buf = this.buf.subarray(end);
          resolve(d);
          return true;
        }
        if (this.buf.length > max) { reject(new Error('header too large')); return true; }
        if (this.ended) { reject(this.error || new Error('unexpected EOF')); return true; }
        return false;
      };
      if (tryOnce()) return;
      const check = () => {
        if (tryOnce()) {
          this.socket.removeListener('data', check);
          this.socket.removeListener('end', check);
          this.socket.removeListener('error', check);
        }
      };
      this.socket.on('data', check);
      this.socket.on('end', check);
      this.socket.on('error', check);
    });
  }

  detach() {
    this.socket.removeListener('data', this.onData);
    this.socket.removeListener('end', this.onEnd);
    this.socket.removeListener('error', this.onErr);
    const rest = this.buf;
    this.buf = Buffer.alloc(0);
    return rest;
  }
}

function parseAuthority(a) {
  let m = a.match(/^\[([^\]]+)\]:(\d+)$/);
  if (m) return { host: m[1], port: Number(m[2]) };
  m = a.match(/^([^:]+):(\d+)$/);
  if (m) return { host: m[1], port: Number(m[2]) };
  return { host: a, port: 80 };
}

function bufToIPv6(b) {
  const g = [];
  for (let i = 0; i < 16; i += 2) g.push(b.readUInt16BE(i).toString(16));
  return g.join(':');
}

function replySocks(sock, code) {
  const b = Buffer.from([5, code, 0, 1, 0, 0, 0, 0, 0, 0]);
  try { sock.end(b); } catch (e) {}
}

async function handleSocks(sock, first, ctx) {
  const r = new Reader(sock, first);
  const h = await r.read(2);
  if (h[0] !== 5) { sock.destroy(); return; }
  const methods = await r.read(h[1]);
  if (!methods.includes(0)) { sock.end(Buffer.from([5, 0xff])); return; }
  sock.write(Buffer.from([5, 0]));
  const req = await r.read(4);
  if (req[0] !== 5 || req[1] !== 1) { replySocks(sock, 7); return; }
  const atyp = req[3];
  let host;
  if (atyp === 1) {
    host = Array.from(await r.read(4)).join('.');
  } else if (atyp === 3) {
    const l = (await r.read(1))[0];
    host = (await r.read(l)).toString('utf8');
  } else if (atyp === 4) {
    host = bufToIPv6(await r.read(16));
  } else {
    replySocks(sock, 8);
    return;
  }
  const pb = await r.read(2);
  const port = pb.readUInt16BE(0);
  const rest = r.detach();
  connectOutbound(ctx, host, port, (err, out) => {
    if (err) { replySocks(sock, 5); return; }
    sock.write(Buffer.from([5, 0, 0, 1, 0, 0, 0, 0, 0, 0]));
    if (rest.length) out.write(rest);
    pipePair(sock, out);
  });
}

async function handleHttp(sock, first, ctx) {
  const r = new Reader(sock, first);
  const head = await r.readUntil('\r\n\r\n', 65536);
  const text = head.toString('latin1');
  const lines = text.split('\r\n');
  const firstLine = lines[0] || '';
  const parts = firstLine.split(' ');
  if (parts.length < 2) { sock.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n'); return; }
  const method = parts[0];
  const target = parts[1];
  const headers = [];
  const hmap = {};
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i];
    if (!line) continue;
    const idx = line.indexOf(':');
    if (idx < 0) continue;
    const k = line.slice(0, idx).trim();
    const v = line.slice(idx + 1).trim();
    headers.push([k, v]);
    hmap[k.toLowerCase()] = v;
  }

  let host;
  let port;
  let path = target;
  let isConnect = false;

  if (method.toUpperCase() === 'CONNECT') {
    const a = parseAuthority(target);
    host = a.host;
    port = a.port;
    isConnect = true;
  } else if (/^https?:\/\//i.test(target)) {
    const u = new URL(target);
    host = u.hostname;
    port = Number(u.port || (u.protocol === 'https:' ? 443 : 80));
    path = u.pathname + u.search;
  } else {
    const a = parseAuthority(hmap.host || '');
    host = a.host;
    port = a.port;
  }
  if (!host) { sock.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n'); return; }

  const rest = r.detach();
  connectOutbound(ctx, host, port, (err, out) => {
    if (err) {
      try { sock.end('HTTP/1.1 502 Bad Gateway\r\nConnection: close\r\n\r\n'); } catch (e) {}
      return;
    }
    if (isConnect) {
      sock.write('HTTP/1.1 200 Connection Established\r\n\r\n');
      if (rest.length) out.write(rest);
    } else {
      let req = method + ' ' + path + ' HTTP/1.1\r\n';
      for (const [k, v] of headers) {
        if (/^(proxy-connection|connection)$/i.test(k)) continue;
        req += k + ': ' + v + '\r\n';
      }
      req += 'Connection: close\r\n\r\n';
      out.write(req);
      if (rest.length) out.write(rest);
    }
    pipePair(sock, out);
  });
}

function pipePair(a, b) {
  a.on('error', () => { try { b.destroy(); } catch (e) {} });
  b.on('error', () => { try { a.destroy(); } catch (e) {} });
  a.on('close', () => { try { b.destroy(); } catch (e) {} });
  b.on('close', () => { try { a.destroy(); } catch (e) {} });
  a.pipe(b);
  b.pipe(a);
}

function connectOutbound(ctx, host, port, cb) {
  let resolved;
  try {
    if (ctx.cfg.mode === 'direct') resolved = { kind: 'direct' };
    else if (ctx.cfg.mode === 'global') resolved = ctx.selector.defaultTarget();
    else resolved = ctx.selector.resolveName(ctx.matcher(host, port));
  } catch (e) {
    return cb(e);
  }
  if (resolved.kind === 'reject') return cb(new Error('rejected by rule'));
  if (resolved.kind === 'direct') {
    const s = net.connect({ host, port });
    s.once('connect', () => cb(null, s));
    s.once('error', cb);
    return;
  }
  const p = resolved.proxy;
  log('route', host + ':' + port, '->', p.name, '(' + p.type + ')', resolved.via);
  if (p.type === 'ss') {
    const s = ss.connect(p, host, port);
    let done = false;
    const timer = setTimeout(() => { if (!done) { done = true; cb(new Error('ss connect timeout')); s.destroy(); } }, 12000);
    s.once('ready', () => { if (!done) { done = true; clearTimeout(timer); cb(null, s); } });
    s.once('error', (e) => { if (!done) { done = true; clearTimeout(timer); cb(e); } });
  } else if (p.type === 'vmess') {
    vmess.connect(p, host, port, ctx, cb);
  } else {
    cb(new Error('unsupported proxy type ' + p.type));
  }
}

function start(ctx) {
  const cfg = ctx.cfg;
  const server = net.createServer((sock) => {
    sock.setNoDelay(true);
    sock.on('error', () => {});
    sock.once('data', (first) => {
      if (first[0] === 5) {
        handleSocks(sock, first, ctx).catch((e) => { log('socks error', e && e.message); try { sock.destroy(); } catch (_) {} });
      } else {
        handleHttp(sock, first, ctx).catch((e) => { log('http error', e && e.message); try { sock.destroy(); } catch (_) {} });
      }
    });
  });
  server.on('error', (e) => {
    if (e && e.code === 'EADDRINUSE') {
      console.error('clash-proxy: port ' + ctx.cfg.port + ' is already in use - another instance is running.');
      console.error('             run "clash-proxy stop" first (or kill the stale process).');
    } else {
      console.error('listen error:', e && e.message);
    }
    process.exit(1);
  });
  server.listen(cfg.port, cfg.listenHost, () => {
    info('mixed proxy listening on ' + cfg.listenHost + ':' + cfg.port);
  });
  return server;
}

module.exports = { start, Reader };
