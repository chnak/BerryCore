'use strict';

const fs = require('fs');
const path = require('path');
const YAML = require('yaml');
const { log } = require('./common');

const SUPPORTED = new Set(['ss', 'vmess']);

function normalizeProxy(p) {
  const type = String(p.type || '').toLowerCase();
  if (!SUPPORTED.has(type)) return null;
  const port = Number(p.port);
  if (!p.name || !p.server || !Number.isInteger(port) || port <= 0 || port > 65535) return null;
  const base = { name: String(p.name), type, server: String(p.server), port, udp: !!p.udp, raw: p };
  if (type === 'ss') {
    if (!p.cipher || !p.password) return null;
    return Object.assign(base, {
      cipher: String(p.cipher).toLowerCase(),
      password: String(p.password),
    });
  }
  const net = String(p.network || 'tcp').toLowerCase();
  const ws = p['ws-opts'] || {};
  const headers = ws.headers || {};
  const hostHeader = headers.Host || headers.host;
  return Object.assign(base, {
    uuid: String(p.uuid || ''),
    alterId: Number(p.alterId || 0) || 0,
    cipher: String(p.cipher || p.security || 'auto').toLowerCase(),
    tls: !!(p.tls || ws.tls),
    servername: p.servername || p.sni || hostHeader || p.server,
    network: net === 'http' ? 'http' : (net === 'ws' ? 'ws' : 'tcp'),
    wsPath: ws.path || '/',
    wsHeaders: headers,
    skipCertVerify: !!p['skip-cert-verify'],
  });
}

function parsePorts(spec) {
  // "80", "80/443", "1000-2000", "80,443" (comma-separated variants already split)
  const out = [];
  for (const part of String(spec).split('/')) {
    const m = part.match(/^(\d+)-(\d+)$/);
    if (m) out.push([Number(m[1]), Number(m[2])]);
    else if (/^\d+$/.test(part)) out.push([Number(part), Number(part)]);
  }
  return out;
}

function parseRules(lines) {
  const list = [];
  const stats = {};
  for (const raw of lines) {
    if (typeof raw !== 'string') continue;
    const s = raw.trim();
    if (!s || s.startsWith('#')) continue;
    const parts = s.split(',');
    const type = parts[0].trim().toUpperCase();
    let r = null;
    if (type === 'MATCH') {
      r = { type, target: parts[1] && parts[1].trim() };
    } else if (type === 'DOMAIN' || type === 'DOMAIN-SUFFIX' || type === 'DOMAIN-KEYWORD') {
      if (parts[1] && parts[2]) r = { type, value: parts[1].trim().toLowerCase(), target: parts[2].trim() };
    } else if (type === 'IP-CIDR' || type === 'IP-CIDR6') {
      if (parts[1] && parts[2]) r = { type, value: parts[1].trim(), target: parts[2].trim(), noResolve: parts.includes('no-resolve') };
    } else if (type === 'DST-PORT') {
      if (parts[1] && parts[2]) r = { type, ports: parsePorts(parts[1]), target: parts[2].trim() };
    } else if (type === 'GEOIP') {
      // no GeoIP database on this device: keep for stats but never match
      r = { type, value: parts[1], target: parts[2], skip: true };
    }
    if (r) list.push(r);
    else stats[type] = (stats[type] || 0) + 1;
  }
  return { list, stats };
}

function readSelected(file) {
  try {
    const f = path.join(path.dirname(file), 'selected');
    return fs.readFileSync(f, 'utf8').trim().split('\n')[0] || '';
  } catch (e) { return ''; }
}

function loadConfig(file, opts) {
  opts = opts || {};
  const doc = YAML.parse(fs.readFileSync(file, 'utf8'));
  if (!doc || !Array.isArray(doc.proxies)) throw new Error('config has no proxies array');

  const proxies = [];
  const byName = new Map();
  let skipped = 0;
  for (const p of doc.proxies) {
    const np = normalizeProxy(p || {});
    if (!np) { skipped++; continue; }
    proxies.push(np);
    byName.set(np.name, np);
  }

  const groups = new Map();
  const groupOrder = [];
  for (const g of (doc['proxy-groups'] || [])) {
    if (!g || !g.name) continue;
    const ng = {
      name: String(g.name),
      type: String(g.type || 'select').toLowerCase(),
      proxies: Array.isArray(g.proxies) ? g.proxies.map(String) : [],
    };
    groups.set(ng.name, ng);
    groupOrder.push(ng.name);
  }

  const rules = parseRules(doc.rules || []);
  const port = Number(doc['mixed-port'] || doc.port || doc['socks-port'] || 7890);
  const socksPort = Number(doc['socks-port'] || 0) || null;
  const listenHost = doc['allow-lan'] ? '0.0.0.0' : '127.0.0.1';

  let defaultGroupName = groupOrder[0] || '';
  for (const name of groupOrder) {
    if (/选择节点|PROXY|GLOBAL/i.test(name)) { defaultGroupName = name; break; }
  }
  const matchRule = rules.list.find(r => r.type === 'MATCH');
  if (matchRule && groups.has(matchRule.target)) defaultGroupName = matchRule.target;

  const selectedName = String(opts.node || process.env.CLASH_NODE || readSelected(file) || '').trim();

  return {
    file, doc, listenHost, port, socksPort, allowLan: !!doc['allow-lan'],
    mode: String(doc.mode || 'rule').toLowerCase(),
    proxies, byName, groups, groupOrder, rules, selectedName, defaultGroupName,
    logLevel: String(doc['log-level'] || 'info').toLowerCase(),
    skippedProxies: skipped,
    ruleStats: rules.stats,
  };
}

module.exports = { loadConfig, normalizeProxy, parseRules };
