'use strict';

const net = require('net');
const { inCidr4, ipv6ToBytes } = require('./common');

function ipv6ToBigInt(ip) {
  const b = ipv6ToBytes(ip);
  let n = 0n;
  for (const x of b) n = (n << 8n) | BigInt(x);
  return n;
}

function inCidr6(ip, cidr) {
  const [base, bitsRaw] = String(cidr).split('/');
  const bits = Number(bitsRaw);
  if (!Number.isInteger(bits) || bits < 0 || bits > 128) return false;
  if (net.isIP(base) !== 6 || net.isIP(ip) !== 6) return false;
  const all = (1n << 128n) - 1n;
  const mask = bits === 0 ? 0n : (all ^ ((1n << BigInt(128 - bits)) - 1n));
  return (ipv6ToBigInt(ip) & mask) === (ipv6ToBigInt(base) & mask);
}

function makeMatcher(cfg) {
  const cache = new Map();

  function match(host, port) {
    const key = host + '|' + port;
    if (cache.has(key)) return cache.get(key);
    const isIP = net.isIP(host);
    let target = null;
    for (const r of cfg.rules.list) {
      if (r.skip) continue;
      switch (r.type) {
        case 'DOMAIN':
          if (isIP === 0 && host === r.value) target = r.target;
          break;
        case 'DOMAIN-SUFFIX':
          if (isIP === 0 && (host === r.value || host.endsWith('.' + r.value))) target = r.target;
          break;
        case 'DOMAIN-KEYWORD':
          if (isIP === 0 && host.includes(r.value)) target = r.target;
          break;
        case 'IP-CIDR':
          if (isIP === 4 && inCidr4(host, r.value)) target = r.target;
          break;
        case 'IP-CIDR6':
          if (isIP === 6 && inCidr6(host, r.value)) target = r.target;
          break;
        case 'DST-PORT':
          if (r.ports.some(([a, b]) => port >= a && port <= b)) target = r.target;
          break;
        case 'MATCH':
          target = r.target;
          break;
        default:
          break;
      }
      if (target) break;
    }
    if (!target) target = cfg.defaultGroupName || null;
    if (cache.size > 2000) cache.clear();
    cache.set(key, target);
    return target;
  }

  return match;
}

function createSelector(cfg) {
  const selectedProxy = cfg.byName.get(cfg.selectedName) || null;

  function groupContains(group, name, depth) {
    depth = depth || 0;
    if (depth > 8 || !group) return false;
    if (group.proxies.includes(name)) return true;
    for (const x of group.proxies) {
      const g = cfg.groups.get(x);
      if (g && groupContains(g, name, depth + 1)) return true;
    }
    return false;
  }

  function defaultTarget() {
    if (selectedProxy) return { kind: 'proxy', proxy: selectedProxy, via: 'selected' };
    const g = cfg.groups.get(cfg.defaultGroupName);
    if (g) {
      for (const x of g.proxies) {
        if (/^REJECT$/i.test(x)) continue;
        const r = resolveName(x, 1);
        if (r.kind !== 'reject') return r;
      }
    }
    if (cfg.proxies.length) return { kind: 'proxy', proxy: cfg.proxies[0], via: 'first' };
    return { kind: 'direct', via: 'none' };
  }

  function resolveName(name, depth) {
    depth = depth || 0;
    if (depth > 10 || !name) return defaultTarget();
    const n = String(name).trim();
    if (/^DIRECT$/i.test(n)) return { kind: 'direct', via: n };
    if (/^REJECT$/i.test(n)) return { kind: 'reject', via: n };
    if (cfg.byName.has(n)) return { kind: 'proxy', proxy: cfg.byName.get(n), via: n };
    const g = cfg.groups.get(n);
    if (!g) return defaultTarget();
    if (selectedProxy && groupContains(g, selectedProxy.name, 0)) {
      return { kind: 'proxy', proxy: selectedProxy, via: g.name + '→' + selectedProxy.name };
    }
    for (const x of g.proxies) {
      if (/^REJECT$/i.test(x)) continue;
      if (/^DIRECT$/i.test(x)) return { kind: 'direct', via: g.name + '→DIRECT' };
      const r = resolveName(x, depth + 1);
      if (r.kind !== 'reject') { r.via = g.name + '→' + (r.via || x); return r; }
    }
    return { kind: 'reject', via: g.name };
  }

  return { resolveName, defaultTarget, selectedProxy };
}

module.exports = { makeMatcher, createSelector, inCidr6 };
