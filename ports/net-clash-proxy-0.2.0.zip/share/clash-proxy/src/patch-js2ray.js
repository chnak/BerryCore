'use strict';

// js2ray 3.0.6 needs a few fixes to be usable as a VMess outbound:
//  1. VMess over raw TCP + TLS is not implemented (only ws/http get tls)
//  2. the wss:// URL is missing the ':' before the port
//  3. the TLS lookup callback uses the wrong signature for Node
//  4. legacy VMess (alterId > 0) uses bare loop variables, which throw
//     ReferenceError under "use strict"
// Apply idempotently to the vendored copy.

const fs = require('fs');
const path = require('path');

let entry;
try {
  entry = require.resolve('js2ray');
} catch (e) {
  console.error('patch-js2ray: js2ray not found:', e.message);
  process.exit(0);
}
const root = path.dirname(entry);

function backupOnce(file, data) {
  const bak = file + '.bb10.bak';
  try { if (!fs.existsSync(bak)) fs.writeFileSync(bak, data); } catch (e) {}
}

function patchFile(file, fn) {
  if (!fs.existsSync(file)) return false;
  const src = fs.readFileSync(file, 'utf8');
  const out = fn(src);
  if (out !== src) {
    backupOnce(file, src);
    fs.writeFileSync(file, out);
    console.log('patch-js2ray: patched', path.basename(file));
    return true;
  }
  return false;
}

// --- core/remoteNetwork.js ---
patchFile(path.join(root, 'core', 'remoteNetwork.js'), (src) => {
  let s = src;
  s = s.split("new WebSocket('wss://' + data.option.tls.serverName + port + data.option.path, {")
       .join("new WebSocket('wss://' + data.option.tls.serverName + ':' + port + data.option.path, {");
  s = s.split('callback(null, [{ "address": address, "family": 4 }], 4);')
       .join('if (options && options.all) callback(null, [{ address: address, family: 4 }]); else callback(null, address, 4);');
  if (!s.includes('bb10 tcp tls')) {
    const start = s.indexOf('} else if (data.type == "tcp") {');
    const end = s.indexOf('} else if (data.type == "ws") {');
    if (start >= 0 && end > start) {
      let block = s.slice(start, end);
      const oldDecl = 'var remotesocket = new net.Socket();';
      if (block.includes(oldDecl)) {
        const newDecl = 'var remotesocket; /* bb10 tcp tls */\n'
          + '                if (data.option && data.option.tls) {\n'
          + "                    remotesocket = require('tls').connect({host: address, port: port, servername: data.option.tls.serverName || address, rejectUnauthorized: data.option.tls.rejectUnauthorized !== false}, remoteConnect);\n"
          + '                } else {\n'
          + '                    remotesocket = new net.Socket();\n'
          + '                }';
        block = block.replace(oldDecl, newDecl);
        block = block.replace(
          'remotesocket.connect(port, address, remoteConnect);',
          'if (!(data.option && data.option.tls)) remotesocket.connect(port, address, remoteConnect);'
        );
        s = s.slice(0, start) + block + s.slice(end);
      }
    }
  }
  return s;
});

// --- protocols/vmess/validator.js ---
patchFile(path.join(root, 'protocols', 'vmess', 'validator.js'), (src) => {
  let s = src;
  s = s.split('for (id of user.user.alterIDs)').join('for (const id of user.user.alterIDs)');
  s = s.split('for (key in v.userHash)').join('for (const key in v.userHash)');
  return s;
});

console.log('patch-js2ray: done');
