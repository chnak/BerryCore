# clash-proxy for BB10 / QNX

A small Clash-compatible local proxy implemented in Node.js (no Linux/iptables
needed). It reads a Clash YAML config (subscription) and exposes a mixed
SOCKS5 + HTTP proxy on `127.0.0.1:7890`.

## Supported

- **Shadowsocks**: AEAD (`aes-128/192/256-gcm`, `chacha20-ietf-poly1305`) and
  legacy stream ciphers (`aes-*-cfb`, `aes-*-ctr`). Tested with the subscription's
  34 SS nodes.
- **VMess**: AEAD (`alterId: 0`) and legacy (`alterId > 0`), transports
  `tcp`, `ws` (+ TLS). Tested with v2ray/Xray servers and the subscription's
  ws VMess nodes.
- **Clash rules**: `DOMAIN`, `DOMAIN-SUFFIX`, `DOMAIN-KEYWORD`, `IP-CIDR`,
  `IP-CIDR6`, `DST-PORT`, `MATCH`. Proxy groups: `select` (first usable entry
  or the explicitly selected node).
- HTTP proxy (CONNECT + absolute URI) and SOCKS5 (no auth) share one port.

## Not supported

- Transparent/TUN mode (QNX has no iptables/nft/TUN); only apps that use the
  system proxy or explicit proxy settings are covered.
- UDP relay, Hysteria2/TUIC, SS2022 ciphers, SS plugins.
- `GEOIP` rules (no GeoIP database); they are ignored.
- VMess over `grpc`/`http` transports.

## Install

```sh
qpkg install node24        # or node-term49
qpkg install clash-proxy
clash-proxy import '<subscription URL>'
clash-proxy start
```

The port installs the code to `$NATIVE_TOOLS/share/clash-proxy` and the
`clash-proxy` command to `$NATIVE_TOOLS/bin`. Subscription data lives in
`/accounts/1000/shared/misc/clash-proxy` when that directory exists, otherwise
in `$HOME/.clash-proxy`; override with `CLASH_PROXY_DIR=/path`.

## Commands

```sh
clash-proxy import '<url>'       # save URL, download + validate config, restart
clash-proxy import '<url>' -n    # same, but do not restart (--no-restart)
clash-proxy start
clash-proxy status
clash-proxy stop
clash-proxy restart
clash-proxy list                 # list nodes/groups
clash-proxy check                # parse config, show selected node
clash-proxy select "<node name>" # choose a node, then restart
clash-proxy update               # re-download subscription.url
```

`import` writes the URL to `subscription.url`, downloads it with `curl`,
validates the YAML with the same parser used at startup, backs up the old
config to `config.yaml.bak`, and restarts a running proxy. The URL is never
echoed (it usually contains credentials). If the subscription host itself
needs the proxy, source `env.sh` first:

```sh
. $NATIVE_TOOLS/share/clash-proxy/env.sh
clash-proxy import 'https://...'
```

Config/data files (mode 600):

- `config.yaml` - Clash YAML subscription
- `config.yaml.bak` - previous config kept by `import`/`update`
- `subscription.url` - URL used by `clash-proxy update`
- `selected` - optional selected node name
- `clash-proxy.log` - runtime log
- `clash-proxy.pid` - pid written by the app (in the code dir)

## Use

CLI tools:

```sh
. /accounts/1000/shared/misc/clash-proxy/env.sh
curl http://example.com                 # HTTP_PROXY/HTTPS_PROXY/ALL_PROXY
```

The env file also sets `NODE_USE_ENV_PROXY=1`, so Node 24 `fetch` honors
`HTTP(S)_PROXY`.

BB10 system proxy:

1. Settings > Network > Wi-Fi > your network > Advanced > Proxy
2. HTTP proxy: `127.0.0.1`, port `7890`

Apps that ignore the BB10 system proxy will not be covered.

Test:

```sh
curl -x http://127.0.0.1:7890 -sS -o /dev/null -w '%{http_code}\n' http://example.com
```

## Notes

- Startup takes roughly 5-10 seconds on the device (Node + YAML parse).
- `clash-proxy start` runs the proxy in a detached tmux session, so it survives
  the shell; `stop` kills that session.
- `start` kills leftover proxy instances first (manual `node src/index.js`
  starts, or a run that crashed), otherwise the new instance dies with
  `EADDRINUSE` and keeps the port busy. It only reports `started` once the log
  shows `mixed proxy listening`; on failure it prints the real error.
- The proxy port is detected by process, not by `netstat`: on QNX a bound
  socket can stay invisible in `netstat` for many seconds.
- The device's `timeout` command is not reliable (it can fire minutes late) —
  the control script polls with `sleep` instead.
- The subscription and node credentials never leave the device; keep
  `config.yaml`, `subscription.url`, `selected` at mode 600.

## Shadowsocks implementation notes

These bugs are easy to reintroduce; keep them in mind when editing `src/ss.js`:

- Keep **separate** `encSubkey` and `decSubkey`. The response salt derives a
  different key; reusing one field makes requests sent after the server's first
  response (e.g. TLS Finished + GET) fail with "message authentication failed".
- The AEAD nonce is a 12-byte **little-endian counter in the first 8 bytes**
  (the last 4 stay zero).
- Node's GCM `cipher.final()` does **not** return the tag; append
  `cipher.getAuthTag()`.
- A chunk length, once decrypted, must be remembered (`pendingLen`) until the
  full payload arrives. Decrypting the length again on the next TCP segment
  consumes a nonce and fails authentication on large/TLS responses.
- Some SS servers send `ECONNRESET` immediately after the final data. Treat it
  as EOF so buffered bytes still reach the client (otherwise large downloads are
  truncated).
