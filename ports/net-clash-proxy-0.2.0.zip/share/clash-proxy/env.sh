# Source this to send CLI tools through clash-proxy:
#   . /accounts/1000/shared/misc/clash-proxy/env.sh
export HTTPS_PROXY=http://127.0.0.1:7890
export HTTP_PROXY=http://127.0.0.1:7890
export ALL_PROXY=socks5://127.0.0.1:7890
export NO_PROXY=127.0.0.1,localhost,192.168.0.0/16,169.254.0.0/16
export NODE_USE_ENV_PROXY=1
