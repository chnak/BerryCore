# node24 - Node.js 24.22.1 for BlackBerry 10 / QNX 6.6

Cross-built Node.js **v24.22.1** with `--with-intl=small-icu` (ICU 78.3,
English/root data embedded), shared libuv, no inspector/snapshot,
OpenSSL no-asm, armle-v7 softfp.

## Install

    qpkg install node24

Then (new shells pick it up automatically):

    . $NATIVE_TOOLS/env.sh
    node -v
    npm -v

## Layout

| Path | Contents |
|------|----------|
| `bin/node.bin` | stripped ARM Node 24.22.1 |
| `bin/node` | wrapper; sets `LD_LIBRARY_PATH` and execs `node.bin` |
| `bin/npm`, `bin/npx` | wrappers for the bundled npm |
| `bin/lib/node_modules/npm/` | npm 11.19.1 (bundled with Node 24) |
| `bin/libuv.so.1` etc. | runtime libs, loaded from `bin/` |
| `etc/npmrc` | `fund=false`, `audit=false` |

Default npm global prefix is `$NATIVE_TOOLS` (node.bin lives in
`$NATIVE_TOOLS/bin`), so `npm install -g` lands in `$NATIVE_TOOLS/bin`
(already on `PATH`) and `$NATIVE_TOOLS/lib/node_modules`.

## Notes

- This port supersedes **node-term49** (Node 22). `qpkg install node24`
  overwrites `bin/node`, `bin/npm`, `bin/node.bin` and friends.
- Do **not** run `qpkg remove node-term49` after installing node24: the two
  ports share those file names, and the old file list would delete node24.
- `Intl.Segmenter`, `Intl.NumberFormat`, `Intl.DateTimeFormat`,
  `Intl.Collator` and Unicode property escapes are enabled.
- Native addons built with node-gyp are not supported (no QNX toolchain in
  the device image); pure-JS packages work normally.
